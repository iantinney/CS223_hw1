/*
Implementations for core functions for Game of Life assignment in CPSC 223 fall 2024

Author: Alan Weide
Modified by: STUDENT NAME HERE
Changelog:
 */

#include "life.h"

#include <stdio.h>

bool is_alive(int field[ROWS][COLS], size_t i, size_t j)
{
    /*
    TODO: Implement this function. This line here only so starter code compiles
    */
    return false;
}

unsigned int num_living_neighbors(int field[ROWS][COLS], size_t i, size_t j)
{
    /*
    TODO: Implement this function. This line here only so starter code compiles
    */
    return 0;
}

int get_next_state(int field[ROWS][COLS], size_t i, size_t j)
{
    /*
    TODO: Implement this function. This line here only so starter code compiles
    */
    return DEAD;
}

void compute_next_gen(int cur_field[ROWS][COLS], int next_field[ROWS][COLS])
{
    /*
    TODO: Implement this function.
     */
}
