#pragma once
/*
Constants for the Game of Life assignment in CPSC 223 Spring 2024.

Author: Alan Weide
*/

#ifndef ROWS
#define ROWS 4
#endif

#ifndef COLS
#define COLS 4
#endif
